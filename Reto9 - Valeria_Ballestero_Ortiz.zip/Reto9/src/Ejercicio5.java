
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Ejercicio5 {

    static List ejercicio5(Set<String> conjunto) {
        Stream<String> streamString = conjunto.stream();
        List<String> nuevaLista = streamString.filter(x -> x.length() >= 5).collect(Collectors.toList());
        return nuevaLista;
    }

}
