
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import javax.swing.JOptionPane;

public class Ejercicio3 {

    static void ejercicio3(String ruta) {
        long valor = 0;
        String fecha = null;
        List<Long> totalValores = new ArrayList<Long>();
        List<String> totalFechas = new ArrayList<String>();
        List<String> totalLineas;
        Path laRuta = Paths.get(ruta);
        Charset charset = Charset.forName("UTF-8");
        try {
            totalLineas = Files.readAllLines(laRuta);
            int numComas = recorrerLinea(totalLineas.get(0));
            for (String lineaActual : totalLineas) {
                if (!lineaActual.equals(totalLineas.get(0))) {
                    valor = obtenerValor(lineaActual, numComas);
                    fecha = obtenerFecha(lineaActual);
                    totalValores.add(valor);
                    totalFechas.add(fecha);
                }
            }
            calculos(totalValores, totalFechas);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    static private int recorrerLinea(String cadena) {
        String palabra = "Volume";
        int contador = 0;
        for (int i = 0; i <= cadena.length() - 1; i++) {
            int j = 0;
            if (cadena.charAt(i) == ',') {
                contador++;
            }
            if (cadena.charAt(i) == palabra.charAt(j)) {
                if ((cadena.substring(i, i + 6)).equals(palabra)) {
                    break;
                }
            }
        }
        return contador;
    }

    static private long obtenerValor(String cadena, int comas) {
        int conteo = 0, j = 0, digitos = 0;
        String dato = null;
        for (int i = 0; i < cadena.length(); i++) {
            j = i + 1;
            if (cadena.charAt(i) == ',') {
                conteo++;
                if (conteo == comas) {
                    while (j < cadena.length() && cadena.charAt(j) != ',') {
                        digitos++;
                        j++;
                    }
                    dato = cadena.substring(i + 1, j);
                    break;
                }
            }
        }
        long valor = Long.valueOf(dato);
        return valor;
    }

    static private String obtenerFecha(String cadena) {
        String nuevaCadena = null;
        int i = 0, contador = 0;
        while (cadena.charAt(i) != ',') {
            contador++;
            i++;
        }
        nuevaCadena = cadena.substring(0, contador);
        return nuevaCadena;
    }

    static private void calculos(List<Long> valores, List<String> fechas) {
        long menor = 0, mayor = 0;
        //El menor volumen------------------
        menor = valores.stream().min((x, y) -> x.compareTo(y)).get();

        //El mayor volumen-------------------
        mayor = valores.stream().max((x, y) -> x.compareTo(y)).get();

        JOptionPane.showMessageDialog(null, "Menor volumen: " + menor + "   Fecha: " + fechas.get(valores.indexOf(menor)) + "\n"
                + "Mayor volumen: " + mayor + "   Fecha: " + fechas.get(valores.indexOf(mayor)), "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }
}
