
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Ejercicio4 {

    static List ejercicio4(List<Double> listaNumeros) {
        Stream<Double> streamLista = listaNumeros.stream();
        List<Double> nuevaLista = streamLista.map(x -> Math.sqrt(x)).collect(Collectors.toList());
        return nuevaLista;
    }
}
