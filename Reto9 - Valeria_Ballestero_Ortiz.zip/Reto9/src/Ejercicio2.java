
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
import javax.swing.JOptionPane;

public class Ejercicio2 {

    static void ejercicio2(String ruta) {
        double valor = 0, promedio = 0, desviacionEstandar;
        List<Double> totalValores = new ArrayList<Double>();
        List<String> totalLineas;
        Path laRuta = Paths.get(ruta);
        Charset charset = Charset.forName("UTF-8");
        try {
            totalLineas = Files.readAllLines(laRuta);
            int numComas = recorrerLinea(totalLineas.get(0));
            for (String lineaActual : totalLineas) {
                if (!lineaActual.equals(totalLineas.get(0))) {
                    valor = obtenerValor(lineaActual, numComas);
                    totalValores.add(valor);
                }
            }

            promedio = obtenerPromedio(totalValores);
            desviacionEstandar = obtenerDesviacion(totalValores, promedio);
            JOptionPane.showMessageDialog(null, "Promedio: " + promedio + "\n" + "Desviación Estándar: " + desviacionEstandar, "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    static int recorrerLinea(String cadena) {
        String palabra = "Close";
        int contador = 0;
        for (int i = 0; i <= cadena.length() - 1; i++) {
            int j = 0;
            if (cadena.charAt(i) == ',') {
                contador++;
            }
            if (cadena.charAt(i) == palabra.charAt(j)) {
                if ((cadena.substring(i, 24)).equals(palabra)) {
                    break;
                }
            }
        }
        return contador;
    }

    static double obtenerValor(String cadena, int comas) {
        int conteo = 0, j = 0, digitos = 0;
        String dato = null;
        for (int i = 0; i < cadena.length(); i++) {
            j = i + 1;
            if (cadena.charAt(i) == ',') {
                conteo++;
                if (conteo == comas) {
                    while (cadena.charAt(j) != ',') {
                        digitos++;
                        j++;
                    }
                    dato = cadena.substring(i + 1, j);
                    break;
                }
            }
        }
        double valor = Double.valueOf(dato.substring(0, 6));
        return valor;
    }

    static double obtenerPromedio(List<Double> totalValores) {
        double total = 0, suma = 0;
        for (double valor : totalValores) {
            suma += valor;
        }
        Stream<Double> streamLista = totalValores.stream();
        total = suma / totalValores.size();
        return total;
    }

    static double obtenerDesviacion(List<Double> totalValores, double media) {
        int N = totalValores.size();
        double sumatoria = 0, varianza = 0, desviacion = 0;
        for (double valor : totalValores) {
            sumatoria = Math.pow(valor - media, 2);
            varianza += sumatoria;
        }
        varianza = varianza / (N - 1);
        desviacion = Math.sqrt(varianza);
        return desviacion;
    }
}
