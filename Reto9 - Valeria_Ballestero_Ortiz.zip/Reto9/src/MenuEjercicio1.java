
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import static java.nio.file.StandardOpenOption.WRITE;
import javax.swing.JOptionPane;
import java.time.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MenuEjercicio1 {

    static String ruta = "D:\\Descargas\\ETH-USD.csv";
    static String respuesta = "";

    public static void main(String[] args) throws CaracterException, IOException {
        //NOMBRE: VALERIA BALLESTERO ORTIZ - CC1001229543
        while (!respuesta.equals("6")) {
            respuesta = JOptionPane.showInputDialog(null, "Elije el ejercicio:\n(1) Lectura/escritura línea por línea\n"
                    + "(2) Promedio y desviación estándar anual(Ethereum)\n(3) Volumen más alto y bajo (Ethereum)\n"
                    + "(4) Recibir y entregar lista con raíz cuadrada\n(5) Recibir HashSet y devolver lista de palabras" + "\n(6) Salir",
                    "Menú | VALERIA BALLESTERO ORTIZ", JOptionPane.QUESTION_MESSAGE);
            switch (respuesta) {
                case "1":
                    ejercicio1();
                    break;
                case "2":
                    Ejercicio2.ejercicio2(ruta);
                    break;
                case "3":
                    Ejercicio3.ejercicio3(ruta);
                    break;
                case "4":
                    List<Double> numeros = Arrays.asList(15.6, 7.8, 4.0, 35.12, 25.9, 10.15);
                    JOptionPane.showMessageDialog(null, "Lista de números a mandar:  " + numeros);
                    numeros = Ejercicio4.ejercicio4(numeros);
                    JOptionPane.showMessageDialog(null, "Lista resultante con raíz cuadrada: " + numeros);
                    break;

                case "5":
                    Set<String> conjunto = new HashSet<String>();
                    conjunto.add("Sol");
                    conjunto.add("Camilo");
                    conjunto.add("Daniela");
                    conjunto.add("Alejandro");
                    conjunto.add("Juan");
                    conjunto.add("Nicol");
                    conjunto.add("Sofi");
                    JOptionPane.showMessageDialog(null, "HashSet con nombres a mandar:  " + conjunto);
                    List<String> listaResultado = Ejercicio5.ejercicio5(conjunto);
                    JOptionPane.showMessageDialog(null, "Nombres con caracteres mayores a 5:  " + listaResultado);
                    break;
                case "6":
                    System.exit(0);
                default:
                    throw new CaracterException();
            }

        }
    }

    static void ejercicio1() {
        LocalDate fecha = LocalDate.now();
        Path miRuta = Paths.get(ruta);
        String cadenaInicio = "2021-11-10,";
        String cadenaCapacidad = "4733.0";
        String linea = null;
        String concepto = null;
        String cadenaFinal = null;
        int bytesInicio = cadenaInicio.getBytes().length, contador = 0;
        int bytesCapacidad = cadenaCapacidad.getBytes().length;
        int bytesTotal = bytesInicio + bytesCapacidad;
        Charset charset = Charset.forName("UTF-8");
        try ( BufferedReader lector = Files.newBufferedReader(miRuta, charset)) {
            linea = lector.readLine();
            while ((linea = lector.readLine()) != null) {
                String precioString = linea.substring(bytesInicio, bytesTotal);
                double precioDouble = Double.valueOf(precioString);
                if (precioDouble < 1200) {
                    concepto = "MUY BAJO";
                } else if (precioDouble >= 1200 && precioDouble < 2100) {
                    concepto = "BAJO    ";
                } else if (precioDouble >= 2100 && precioDouble < 3100) {
                    concepto = "MEDIO   ";
                } else if (precioDouble >= 3100 && precioDouble < 4600) {
                    concepto = "ALTO    ";
                } else if (precioDouble >= 4600) {
                    concepto = "MUY ALTO";
                }
                cadenaFinal = fecha + "\t" + concepto + "\t" + precioString + "\n";
                adicionarInformacion(cadenaFinal, contador);
                contador++;
            }
            Path documento = Paths.get("concepto.txt");
            JOptionPane.showMessageDialog(null, "Datos guardados en el archivo: " + documento.getFileName() + "\nPor favor revisar el documento", "Información", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            e.getMessage();
        }
    }

    static private void adicionarInformacion(String cadena, int num) throws IOException {
        if (num == 0) {
            Path otraRuta = Paths.get("concepto.txt");
            byte[] bytesCadena = cadena.getBytes();
            Files.write(otraRuta, bytesCadena);
        } else {
            int numBytes = cadena.getBytes().length;
            int byteInicial = numBytes * num;
            Path otraRuta = Paths.get("concepto.txt");
            FileChannel canal = FileChannel.open(otraRuta, WRITE);
            canal.position(byteInicial);
            ByteBuffer buffer = ByteBuffer.wrap(cadena.getBytes());
            canal.write(buffer);
        }

    }

}
