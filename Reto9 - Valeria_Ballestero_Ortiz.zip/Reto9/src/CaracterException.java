
public class CaracterException extends Exception {

    public CaracterException() {
        super("Respuesta errónea. Vuelva a iniciar");
    }

}
